This release includes FOTA update from mfw_nrf9160_1.2.1 release to mfw_nrf9160_1.2.2 release.
FOTA update filename is mfw_nrf9160_update_from_1.2.1_to_1.2.2.bin.

This release includes FOTA-TEST images between mfw_nrf9160_1.2.2 release and mfw_nrf9160_1.2.2-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.2.2_to_1.2.2-FOTA-TEST and mfw_nrf9160_update_from_1.2.2-FOTA-TEST_to_1.2.2.

UUID of mfw_nrf9160_1.2.2 is fcb82d0b-2da7-4610-9107-49b0043983a8
UUID of mfw_nrf9160_1.2.2-FOTA-TEST is b7ed8da6-0587-44da-8bca-110beb4929d9