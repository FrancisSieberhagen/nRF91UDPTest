This release is not FOTA updatable from previous modem firmware releases.
This release includes FOTA-TEST images between mfw_nrf9160_1.2.0 release and mfw_nrf9160_1.2.0-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.2.0_to_1.2.0-FOTA-TEST and mfw_nrf9160_update_from_1.2.0-FOTA-TEST_to_1.2.0.